﻿using HarmonyLib;
using KMod;

namespace $safeprojectname$
{
    public class Patch : UserMod2
    {
        public override void OnLoad(Harmony harmony)
        {
            base.OnLoad(harmony);
            Debug.Log("Mod - $safeprojectname$ - 已加载并初始化。");

        }


        [HarmonyPatch(typeof(ElectrolyzerConfig), "CreateBuildingDef")]
        public class MyFirstPatch
        {
            // Postfix 代表后置补丁
            public static void Postfix(ref BuildingDef __result)
            {
                // 将电解器的功耗改为 1 瓦
                __result.EnergyConsumptionWhenActive = 1f;
                Debug.Log("电解器的功耗已被修改为 1 瓦");
            }
        }

    }
}
